#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#define VERSION 1.0             /* Version of nlist */
#define DEBUG 0                 /* set to 1 to turn on debugging */
#define MAXSTR 255              /* max string size */
/* Start of Main program */
main (argc, argv)
  int             argc;
  char          **argv;
{
  float x, y, z;
  /* %6.2f */
  x = 1.0;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 5000.0;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 500000000.0;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 18014398509481984.0;
  printf ("f %f 6.2f %6.2f\n", x, x);
  /* test rounding */
  x = 0.005;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.005;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.001;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.001;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.007;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.007;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.015;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.015;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.011;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.011;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.017;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -0.017;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = 0.09999999999;
  printf ("f %f 6.2f %6.2f\n", x, x);
    x  = 0.0000000005;
  printf ("f %f 6.2f %6.2f\n", x, x);
    x  = 0.0;
   printf ("f %f 6.2f %6.2f\n", x, x);
 x = 3.1415926535;
  printf ("f %f 6.2f %6.2f\n", x, x);
    x  = 105.7;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -10.0;
  printf ("f %f 6.2f %6.2f\n", x, x);
  x = -10.0;
  printf ("F %F 6.2F %6.2F\n", x, x);
  /* e */
  x = 1.0;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = 5000.0;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = 500000000.0;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = 18014398509481984.0;
  /*  x = pow(2.0,54.0); */
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = 0.0000000005;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = 3.1415926535;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x  = 102.7;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  x = -10.0;
  printf ("e %e 6.2e %6.2e 12.6e %12.6e \n", x, x, x);
  /* E */
  x = 1.0;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 5000.0;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 500000000.0;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 18014398509481984.0;
  /*  x = pow(2.0,54.0); */
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 0.09999999999;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 0.0000000005;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = 3.1415926535;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x  = 102.7;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  x = -10.0;
  printf ("E %E 6.2E %6.2E 12.6E %12.6E \n", x, x, x);
  /* 13.6e */
  x = 1.0;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  x = 5000.0;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  x = 18014398509481984.0;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  x = 0.0000000005;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  x = 3.1415926535;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
    x   = 102.7;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  x = -10.0;
  printf ("13.6e %13.6e 12.3e % 12.3e\n", x, x);
  /* check - and . */
  x = 1.0;
  printf ("-13.6e %-13.6e .13.6e %.13.6e\n", x, x);
  /* 13.3e */
  x = 1.0;
  printf ("13.3e %13.3e -13.3e %-13.3e .13.3e %.13.3e .6.3e %.6.3e\n", x, x, x, x);
  /* %g */
  x = 1.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 5000.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 50000.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 500000.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 5000000.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 18014398509481984.00;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 500000000.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0000000005;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.09999999999;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.1234567;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0234567;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0034567;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0004567;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0000567;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.005;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = -0.001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = -0.0001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = -0.00001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.00001;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 0.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = 3.1415926535;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
    x  = 102.7;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = -10.0;
  printf ("g %g 6.2g %6.2g 6g %6g 5.2g %5.2g 6.3g %6.3g\n", x, x, x, x, x);
  x = -0.00001;
  printf ("G %G 6.2G %6.2G 6G %6G 5.2G %5.2G 6.3G %6.3G\n", x, x, x, x, x);

  printf ("A test\n");
  x = 6.5;
  printf ("A %A a %a 9A %9A 9a %9a 9.4a %9.4a 9.4A %9.4A\n", x, x, x, x, x, x);

  /* div/mod test */
  x = 4.0;
  y = 4.3333333;
  z = fmod (x, y);
  printf ("%f mod %f = %f\n", x, y, z);
  z = fmod (y, x);
  printf ("%f mod %f = %f\n", y, x, z);
  x = 4.0;
  y = -4.3333333;
  z = fmod (x, y);
  printf ("%f mod %f = %f\n", x, y, z);
  z = fmod (y, x);
  printf ("%f mod %f = %f\n", y, x, z);
  x = -4.0;
  y = 4.3333333;
  z = fmod (x, y);
  printf ("%f mod %f = %f\n", x, y, z);
  z = fmod (y, x);
  printf ("%f mod %f = %f\n", y, x, z);
  x = -4.0;
  y = -4.3333333;
  z = fmod (x, y);
  printf ("%f mod %f = %f\n", x, y, z);
  z = fmod (y, x);
  printf ("%f mod %f = %f\n", y, x, z);
  exit(0);
}
